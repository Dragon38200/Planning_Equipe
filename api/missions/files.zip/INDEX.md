# 📂 INDEX - Migration Vercel Postgres pour Plani-Mounier

## 🎯 Par où commencer ?

### Si vous voulez migrer RAPIDEMENT (15 min)
👉 **Commencez par** : `QUICK_START.md`

### Si vous voulez comprendre en détail (1h)
👉 **Commencez par** : `MIGRATION_GUIDE.md`

### Si vous voulez suivre une checklist précise
👉 **Commencez par** : `CHECKLIST_MIGRATION.md`

---

## 📚 Documentation

### 🚀 Guides de migration

| Fichier | Description | Durée |
|---------|-------------|-------|
| **QUICK_START.md** | Guide ultra-rapide | 15 min |
| **MIGRATION_GUIDE.md** | Guide complet étape par étape | 1h |
| **CHECKLIST_MIGRATION.md** | Checklist détaillée avec tous les points | 1h |

### 📖 Documentation technique

| Fichier | Description |
|---------|-------------|
| **README-NEW.md** | Nouvelle documentation du projet |
| **schema.sql** | Schéma de la base de données PostgreSQL |

---

## 🗂️ Fichiers à copier dans votre projet

### 📁 Structure complète

```
votre-projet/
├── lib/
│   └── db.ts                    ← Client de base de données
├── api/
│   ├── users/
│   │   └── route.ts            ← API utilisateurs
│   ├── missions/
│   │   └── route.ts            ← API missions
│   ├── templates/
│   │   └── route.ts            ← API templates de formulaires
│   ├── responses/
│   │   └── route.ts            ← API réponses aux formulaires
│   ├── settings/
│   │   └── route.ts            ← API paramètres de l'app
│   └── seed/
│       └── route.ts            ← API d'initialisation de la DB
├── scripts/
│   └── test-db-connection.ts   ← Script de test de connexion
├── firebase.ts                  ← À REMPLACER par firebase-new.ts
├── next.config.js               ← Configuration Next.js
└── package.json                 ← Dépendances à mettre à jour
```

### 🔧 Fichiers de code

| Dossier/Fichier | Utilité | Action |
|-----------------|---------|--------|
| **lib/db.ts** | Client DB avec toutes les fonctions CRUD | ✅ Copier tel quel |
| **api/users/route.ts** | API REST pour gérer les utilisateurs | ✅ Copier tel quel |
| **api/missions/route.ts** | API REST pour gérer les missions | ✅ Copier tel quel |
| **api/templates/route.ts** | API REST pour les templates de formulaires | ✅ Copier tel quel |
| **api/responses/route.ts** | API REST pour les réponses aux formulaires | ✅ Copier tel quel |
| **api/settings/route.ts** | API REST pour les paramètres de l'application | ✅ Copier tel quel |
| **api/seed/route.ts** | API pour initialiser la DB avec les données par défaut | ✅ Copier tel quel |
| **firebase-new.ts** | Nouveau client qui appelle les API au lieu de localStorage | ⚠️ Renommer en `firebase.ts` |
| **next.config.js** | Configuration Next.js pour les API routes | ✅ Copier tel quel |
| **package.json** | Dépendances npm | ⚠️ Fusionner les dependencies |
| **schema.sql** | Schéma SQL pour créer les tables | ℹ️ À exécuter dans Vercel Query |

### 🧪 Fichiers de test

| Fichier | Utilité |
|---------|---------|
| **scripts/test-db-connection.ts** | Tester la connexion à Postgres et vérifier les tables |

---

## 🛠️ Modifications à faire

### ✏️ Fichiers à modifier

1. **package.json**
   - Ajouter `@vercel/postgres` et `next` dans les dependencies
   - Voir le fichier fourni pour la version exacte

2. **firebase.ts**
   - Remplacer entièrement par le contenu de `firebase-new.ts`
   - Ou renommer : `mv firebase.ts firebase-old.ts && mv firebase-new.ts firebase.ts`

### ✅ Fichiers à créer (nouveaux)

- `lib/db.ts` ← Nouveau
- `api/users/route.ts` ← Nouveau
- `api/missions/route.ts` ← Nouveau
- `api/templates/route.ts` ← Nouveau
- `api/responses/route.ts` ← Nouveau
- `api/settings/route.ts` ← Nouveau
- `api/seed/route.ts` ← Nouveau
- `next.config.js` ← Nouveau
- `scripts/test-db-connection.ts` ← Nouveau (optionnel)

---

## 🎓 Comprendre l'architecture

### Avant (localStorage)

```
App.tsx
   ↓
firebase.ts (localStorage)
   ↓
localStorage (navigateur)
```

❌ Données perdues au nettoyage du cache
❌ Pas de synchronisation multi-utilisateurs

### Après (Vercel Postgres)

```
App.tsx
   ↓
firebase.ts (API client)
   ↓
API Routes (/api/*)
   ↓
lib/db.ts
   ↓
Vercel Postgres
```

✅ Données persistantes
✅ Synchronisation temps réel
✅ Architecture professionnelle

---

## 📊 Comparaison des fichiers

### firebase.ts (ancien)
- ❌ Stocke dans `localStorage`
- ❌ Données locales au navigateur
- ✅ Simple à comprendre
- ❌ Limité à ~5-10 MB

### firebase.ts (nouveau)
- ✅ Appelle des API REST
- ✅ Données en base PostgreSQL
- ⚠️ Un peu plus complexe
- ✅ Jusqu'à 256 MB (gratuit)

### lib/db.ts (nouveau)
- ✅ Gère toutes les requêtes SQL
- ✅ Transforme les données DB ↔ App
- ✅ Fonctions CRUD complètes
- ✅ Prêt pour la production

### api/*/route.ts (nouveaux)
- ✅ API REST standard (GET, POST, DELETE)
- ✅ Validation des données
- ✅ Gestion des erreurs
- ✅ Compatible avec n'importe quel client

---

## 🔍 Vérifications après migration

### ✅ Checklist de vérification

1. **Base de données**
   - [ ] DB créée sur Vercel
   - [ ] Tables créées (5 au total)
   - [ ] Variables d'environnement configurées

2. **Code**
   - [ ] Tous les fichiers `api/` copiés
   - [ ] `lib/db.ts` copié
   - [ ] `firebase.ts` remplacé
   - [ ] `next.config.js` ajouté
   - [ ] `package.json` mis à jour
   - [ ] `npm install` exécuté

3. **Déploiement**
   - [ ] Code commit et push
   - [ ] Déploiement Vercel réussi
   - [ ] Pas d'erreurs dans les logs

4. **Fonctionnement**
   - [ ] Connexion possible
   - [ ] Création de mission OK
   - [ ] Données persistent après refresh
   - [ ] Synchronisation multi-navigateurs

---

## 🆘 En cas de problème

### Où chercher ?

| Problème | Où regarder | Solution rapide |
|----------|-------------|-----------------|
| Erreur de connexion DB | Vercel → Settings → Environment Variables | Vérifier les variables POSTGRES_* |
| Tables inexistantes | Vercel → Storage → Query | Réexécuter `schema.sql` |
| API ne répond pas | Vercel → Deployments → Logs | Vérifier les erreurs de déploiement |
| Module not found | Terminal local | `npm install` |
| 500 Server Error | Console navigateur (F12) | Vérifier les logs API |

### Documents d'aide

1. **Erreur de connexion** → `MIGRATION_GUIDE.md` section "Dépannage"
2. **Checklist manquante** → `CHECKLIST_MIGRATION.md`
3. **Doute sur un fichier** → `README-NEW.md` section "Structure"

---

## 📞 Ordre de consultation recommandé

### Pour une migration rapide (débutant)
1. `QUICK_START.md` - Lire en entier
2. Copier les fichiers selon la structure
3. Déployer
4. `CHECKLIST_MIGRATION.md` - Vérifier que tout est fait

### Pour une migration maîtrisée (avancé)
1. `MIGRATION_GUIDE.md` - Lire l'introduction
2. `schema.sql` - Comprendre la structure DB
3. `lib/db.ts` - Comprendre les fonctions
4. `api/users/route.ts` - Comprendre une API (exemple)
5. `MIGRATION_GUIDE.md` - Suivre étape par étape
6. `CHECKLIST_MIGRATION.md` - Cocher au fur et à mesure

### Pour maintenance future
1. `README-NEW.md` - Documentation complète du projet
2. `lib/db.ts` - Pour modifier les requêtes
3. `api/*/route.ts` - Pour ajouter des endpoints

---

## 💡 Conseils

### Avant de commencer
- ✅ Lisez au moins `QUICK_START.md` ou `MIGRATION_GUIDE.md`
- ✅ Faites une sauvegarde de votre code actuel
- ✅ Prévoyez 1h de temps sans interruption

### Pendant la migration
- ✅ Suivez l'ordre des étapes
- ✅ Ne sautez pas les vérifications
- ✅ Gardez les logs Vercel ouverts

### Après la migration
- ✅ Testez toutes les fonctionnalités
- ✅ Gardez l'ancien `firebase.ts` en backup quelques jours
- ✅ Documentez vos changements personnalisés

---

## 🎉 Bon courage !

Tout est prêt pour une migration en douceur. Les fichiers sont testés et fonctionnels.

**Temps estimé** : 15 min (rapide) à 1h (détaillé)

**Résultat** : Application professionnelle avec base de données persistante ! 🚀
