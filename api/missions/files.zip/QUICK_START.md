# 🚀 DÉMARRAGE RAPIDE - Migration Vercel Postgres

## ⚡ Version ultra-rapide (15 minutes)

### 1️⃣ Sur Vercel (5 min)
1. Ouvrez [vercel.com](https://vercel.com) → votre projet
2. **Storage** → **Create Database** → **Postgres**
3. Nom: `plani-mounier-db` | Région: `fra1`
4. **Connect Project** → sélectionnez votre projet
5. **Query** → Collez le contenu de `schema.sql` → **Run Query**

### 2️⃣ Dans votre projet (8 min)
```bash
# 1. Créer la structure
mkdir -p lib api/users api/missions api/templates api/responses api/settings api/seed scripts

# 2. Copier les fichiers (voir ci-dessous)

# 3. Remplacer firebase.ts
mv firebase.ts firebase-old.ts.backup
mv firebase-new.ts firebase.ts

# 4. Installer les dépendances
npm install @vercel/postgres@^0.10.0 next@^14.2.0

# 5. Déployer
git add .
git commit -m "Migration Postgres"
git push
```

### 3️⃣ Fichiers à copier

Copiez ces fichiers dans votre projet :

```
📁 votre-projet/
├── lib/
│   └── db.ts                    ← Copier
├── api/
│   ├── users/route.ts          ← Copier
│   ├── missions/route.ts       ← Copier
│   ├── templates/route.ts      ← Copier
│   ├── responses/route.ts      ← Copier
│   ├── settings/route.ts       ← Copier
│   └── seed/route.ts           ← Copier
├── scripts/
│   └── test-db-connection.ts   ← Copier
├── firebase.ts                  ← REMPLACER par firebase-new.ts
├── next.config.js               ← Copier
├── package.json                 ← Mettre à jour les dependencies
└── schema.sql                   ← Référence (déjà utilisé sur Vercel)
```

### 4️⃣ Vérification (2 min)

Une fois déployé :

1. Accédez à votre app
2. Connectez-vous (admin / admin123)
3. Créez une mission
4. Rafraîchissez → Données toujours là ✅

---

## 📋 Fichiers modifiés

### ✏️ `package.json`
Ajoutez dans `dependencies` :
```json
"@vercel/postgres": "^0.10.0",
"next": "^14.2.0"
```

### 🔄 `firebase.ts`
Remplacez entièrement par le contenu de `firebase-new.ts`

---

## 🆘 Problèmes courants

### ❌ "Cannot connect to database"
→ Variables d'environnement manquantes
→ Vérifiez Settings → Environment Variables sur Vercel

### ❌ "Table does not exist"
→ Schéma SQL non exécuté
→ Relancez `schema.sql` dans la console Query

### ❌ "Module not found: @vercel/postgres"
→ Dépendances non installées
→ Relancez `npm install`

---

## 📚 Documentation complète

Pour plus de détails, consultez :
- **MIGRATION_GUIDE.md** : Guide complet pas à pas
- **CHECKLIST_MIGRATION.md** : Checklist détaillée
- **README-NEW.md** : Documentation du projet

---

## ✅ Checklist express

- [ ] DB Postgres créée sur Vercel
- [ ] `schema.sql` exécuté avec succès
- [ ] Fichiers `lib/` et `api/` copiés
- [ ] `firebase.ts` remplacé
- [ ] `package.json` mis à jour
- [ ] `npm install` exécuté
- [ ] Code déployé (`git push`)
- [ ] Tests OK (connexion, création mission)

---

## 🎉 C'est fait !

Votre application utilise maintenant Vercel Postgres !

**Avantages immédiats** :
✅ Données persistantes (plus de perte)
✅ Synchronisation multi-utilisateurs
✅ Base de données professionnelle
✅ Backups automatiques

**Temps total** : ~15 minutes

---

💡 **Astuce** : Gardez l'ancien `firebase.ts` en backup pendant quelques jours, au cas où.
