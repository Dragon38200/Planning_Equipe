# 🚀 Guide de Migration vers Vercel Postgres

Ce guide explique comment migrer votre application Plani-Mounier du stockage localStorage vers une base de données Vercel Postgres persistante.

---

## 📋 Prérequis

- Un compte Vercel (gratuit)
- Votre application déjà déployée sur Vercel
- Node.js 18+ installé localement

---

## 🗄️ Étape 1 : Créer une base de données Vercel Postgres

### 1.1 Accéder au Dashboard Vercel

1. Connectez-vous à [vercel.com](https://vercel.com)
2. Sélectionnez votre projet **plani-mounier**
3. Cliquez sur l'onglet **Storage** dans le menu

### 1.2 Créer la base de données

1. Cliquez sur **Create Database**
2. Sélectionnez **Postgres**
3. Donnez un nom à votre base (ex: `plani-mounier-db`)
4. Choisissez la région **la plus proche de vos utilisateurs** (ex: `fra1` pour Paris)
5. Cliquez sur **Create**

⏱️ *La création prend environ 1-2 minutes*

### 1.3 Connecter la base au projet

1. Une fois créée, cliquez sur **Connect Project**
2. Sélectionnez votre projet **plani-mounier**
3. Cliquez sur **Connect**

✅ Vercel va automatiquement ajouter les variables d'environnement nécessaires à votre projet.

---

## 🏗️ Étape 2 : Initialiser le schéma de la base de données

### 2.1 Accéder à la console SQL

1. Dans le dashboard Vercel, allez dans **Storage** → votre base de données
2. Cliquez sur l'onglet **Query**

### 2.2 Exécuter le script SQL

1. Ouvrez le fichier `schema.sql` fourni
2. **Copiez tout le contenu** du fichier
3. **Collez-le** dans la console Query de Vercel
4. Cliquez sur **Run Query** (bouton vert en haut à droite)

✅ Vous devriez voir le message "Query executed successfully"

### 2.3 Vérifier la création des tables

Dans la console Query, exécutez :
```sql
SELECT table_name FROM information_schema.tables 
WHERE table_schema = 'public';
```

Vous devriez voir :
- `users`
- `missions`
- `form_templates`
- `form_responses`
- `app_settings`

---

## 📦 Étape 3 : Mettre à jour le code de l'application

### 3.1 Structure de fichiers à créer

Créez la structure suivante dans votre projet :

```
votre-projet/
├── lib/
│   └── db.ts                    ← Nouveau fichier fourni
├── api/
│   ├── users/
│   │   └── route.ts            ← Nouveau fichier fourni
│   ├── missions/
│   │   └── route.ts            ← Nouveau fichier fourni
│   ├── templates/
│   │   └── route.ts            ← Nouveau fichier fourni
│   ├── responses/
│   │   └── route.ts            ← Nouveau fichier fourni
│   ├── settings/
│   │   └── route.ts            ← Nouveau fichier fourni
│   └── seed/
│       └── route.ts            ← Nouveau fichier fourni
├── firebase.ts                  ← Remplacer par firebase-new.ts
└── package.json                 ← Mettre à jour
```

### 3.2 Copier les nouveaux fichiers

Tous les fichiers nécessaires ont été générés :

1. **Copiez** le contenu de `lib/db.ts` → créez ce fichier dans votre projet
2. **Copiez** tous les fichiers `api/*/route.ts` → créez ces fichiers dans votre projet
3. **Remplacez** `firebase.ts` par le contenu de `firebase-new.ts`

### 3.3 Mettre à jour package.json

Ajoutez les dépendances suivantes dans votre `package.json` :

```json
"dependencies": {
  "@vercel/postgres": "^0.10.0",
  "next": "^14.2.0"
}
```

Puis exécutez :
```bash
npm install
```

---

## 🔄 Étape 4 : Migrer les données existantes (optionnel)

Si vous avez des données dans localStorage que vous voulez conserver :

### Option A : Réinitialiser avec les données par défaut

L'application va automatiquement créer les données par défaut au premier chargement.

### Option B : Migrer vos données localStorage

1. Créez un script de migration `migrate-local-data.ts` :

```typescript
// migrate-local-data.ts
import { saveUser, saveMission, saveTemplate, saveResponse } from './lib/db';

async function migrateLocalStorageData() {
  // Récupérer les données du localStorage
  const users = JSON.parse(localStorage.getItem('users') || '[]');
  const missions = JSON.parse(localStorage.getItem('missions') || '[]');
  const templates = JSON.parse(localStorage.getItem('templates') || '[]');
  const responses = JSON.parse(localStorage.getItem('responses') || '[]');

  // Migrer les utilisateurs
  for (const user of users) {
    await saveUser(user);
  }

  // Migrer les missions
  for (const mission of missions) {
    await saveMission(mission);
  }

  // Migrer les templates
  for (const template of templates) {
    await saveTemplate(template);
  }

  // Migrer les réponses
  for (const response of responses) {
    await saveResponse(response);
  }

  console.log('Migration terminée !');
}

// Exécuter la migration
migrateLocalStorageData();
```

2. Ajoutez un bouton temporaire dans votre interface admin pour exécuter ce script

---

## 🚀 Étape 5 : Déployer sur Vercel

### 5.1 Commit et push

```bash
git add .
git commit -m "Migration vers Vercel Postgres"
git push
```

### 5.2 Vérification du déploiement

1. Vercel va automatiquement déployer votre nouvelle version
2. Attendez que le déploiement soit terminé (2-3 minutes)
3. Vérifiez les logs dans le dashboard Vercel

### 5.3 Initialiser les données

1. Accédez à votre application déployée
2. L'application va automatiquement initialiser la base de données avec les données par défaut au premier chargement
3. Vous pouvez aussi forcer l'initialisation en appelant `/api/seed` :

```bash
curl -X POST https://votre-app.vercel.app/api/seed
```

---

## ✅ Étape 6 : Vérification

### Test de fonctionnement

1. **Connexion** : Connectez-vous avec un compte (ex: admin / admin123)
2. **Créer une mission** : Vérifiez que vous pouvez créer une mission
3. **Rafraîchir la page** : Les données doivent persister (plus de perte !)
4. **Ouvrir un autre navigateur** : Les données doivent être synchronisées

### Vérifier les données en base

Dans la console Query de Vercel :

```sql
-- Compter les utilisateurs
SELECT COUNT(*) FROM users;

-- Compter les missions
SELECT COUNT(*) FROM missions;

-- Voir les dernières missions
SELECT * FROM missions ORDER BY created_at DESC LIMIT 10;
```

---

## 🔧 Dépannage

### Problème : "Failed to connect to database"

**Solution** :
- Vérifiez que les variables d'environnement sont bien configurées dans Vercel
- Allez dans **Settings** → **Environment Variables**
- Vérifiez la présence de `POSTGRES_URL`, `POSTGRES_PRISMA_URL`, etc.

### Problème : "Table does not exist"

**Solution** :
- Réexécutez le script `schema.sql` dans la console Query
- Vérifiez que toutes les requêtes se sont exécutées sans erreur

### Problème : "500 Internal Server Error"

**Solution** :
- Consultez les logs dans Vercel Dashboard → votre projet → **Logs**
- Vérifiez que toutes les dépendances sont installées (`npm install`)

### Problème : Les données ne se chargent pas

**Solution** :
- Ouvrez la console du navigateur (F12)
- Vérifiez les erreurs réseau dans l'onglet Network
- Assurez-vous que les routes API répondent correctement

---

## 📊 Limites du Plan Gratuit Vercel Postgres

- **Storage** : 256 MB
- **Compute** : 60 heures/mois
- **Rows** : ~500,000 lignes

💡 **Pour votre usage**, c'est largement suffisant ! Une mission = ~1 KB, donc vous pouvez stocker des centaines de milliers de missions.

---

## 🎯 Avantages de la migration

✅ **Données persistantes** : Plus de perte de données au nettoyage du cache  
✅ **Multi-utilisateurs** : Tous les utilisateurs voient les mêmes données en temps réel  
✅ **Sécurisé** : Données chiffrées et backupées automatiquement  
✅ **Scalable** : Peut gérer des milliers d'utilisateurs et de missions  
✅ **Rapide** : Base de données optimisée pour les requêtes  

---

## 🆘 Besoin d'aide ?

Si vous rencontrez un problème :

1. Consultez les logs Vercel
2. Vérifiez la console navigateur (F12)
3. Testez les routes API directement :
   - `https://votre-app.vercel.app/api/users`
   - `https://votre-app.vercel.app/api/missions`

---

## 📝 Checklist de migration

- [ ] Base de données Vercel Postgres créée
- [ ] Base de données connectée au projet
- [ ] Schéma SQL exécuté avec succès
- [ ] Fichiers `lib/db.ts` et `api/*/route.ts` créés
- [ ] `firebase.ts` remplacé par la nouvelle version
- [ ] `package.json` mis à jour avec les nouvelles dépendances
- [ ] `npm install` exécuté
- [ ] Code commit et push sur GitHub
- [ ] Application déployée sur Vercel
- [ ] Données initialisées (via `/api/seed`)
- [ ] Tests de fonctionnement OK

---

## 🎉 Félicitations !

Votre application utilise maintenant une vraie base de données professionnelle ! 🚀

Les données sont maintenant :
- ✅ Persistantes
- ✅ Partagées entre tous les utilisateurs
- ✅ Sauvegardées automatiquement
- ✅ Accessibles depuis n'importe quel appareil
