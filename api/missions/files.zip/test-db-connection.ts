// scripts/test-db-connection.ts
/**
 * Script de test de connexion à la base de données Vercel Postgres
 * 
 * Usage: 
 * 1. Assurez-vous d'avoir les variables d'environnement configurées
 * 2. Exécutez: npx ts-node scripts/test-db-connection.ts
 */

import { sql } from '@vercel/postgres';

async function testConnection() {
  console.log('🔍 Test de connexion à Vercel Postgres...\n');

  try {
    // Test 1: Connexion basique
    console.log('1️⃣ Test de connexion...');
    const { rows: versionRows } = await sql`SELECT version()`;
    console.log('✅ Connexion réussie !');
    console.log(`   PostgreSQL version: ${versionRows[0].version.split(' ')[1]}\n`);

    // Test 2: Vérification des tables
    console.log('2️⃣ Vérification des tables...');
    const { rows: tables } = await sql`
      SELECT table_name 
      FROM information_schema.tables 
      WHERE table_schema = 'public'
      ORDER BY table_name
    `;
    
    const expectedTables = [
      'app_settings',
      'form_responses',
      'form_templates',
      'missions',
      'users'
    ];
    
    console.log('   Tables trouvées:');
    tables.forEach((t: any) => {
      const isExpected = expectedTables.includes(t.table_name);
      console.log(`   ${isExpected ? '✅' : '❌'} ${t.table_name}`);
    });
    
    const missingTables = expectedTables.filter(
      t => !tables.some((row: any) => row.table_name === t)
    );
    
    if (missingTables.length > 0) {
      console.log(`\n   ⚠️  Tables manquantes: ${missingTables.join(', ')}`);
      console.log('   → Exécutez le script schema.sql dans la console Vercel\n');
    } else {
      console.log('   ✅ Toutes les tables sont présentes !\n');
    }

    // Test 3: Compter les enregistrements
    console.log('3️⃣ Comptage des enregistrements...');
    
    const { rows: userCount } = await sql`SELECT COUNT(*) as count FROM users`;
    console.log(`   👥 Utilisateurs: ${userCount[0].count}`);
    
    const { rows: missionCount } = await sql`SELECT COUNT(*) as count FROM missions`;
    console.log(`   📋 Missions: ${missionCount[0].count}`);
    
    const { rows: templateCount } = await sql`SELECT COUNT(*) as count FROM form_templates`;
    console.log(`   📝 Templates: ${templateCount[0].count}`);
    
    const { rows: responseCount } = await sql`SELECT COUNT(*) as count FROM form_responses`;
    console.log(`   💬 Réponses: ${responseCount[0].count}`);
    
    const { rows: settingsCount } = await sql`SELECT COUNT(*) as count FROM app_settings`;
    console.log(`   ⚙️  Paramètres: ${settingsCount[0].count}\n`);

    // Test 4: Test de lecture
    console.log('4️⃣ Test de lecture (derniers utilisateurs)...');
    const { rows: users } = await sql`
      SELECT id, name, role 
      FROM users 
      ORDER BY created_at DESC 
      LIMIT 5
    `;
    
    if (users.length > 0) {
      console.log('   Utilisateurs récents:');
      users.forEach((u: any) => {
        console.log(`   - ${u.name} (${u.role})`);
      });
    } else {
      console.log('   ℹ️  Aucun utilisateur trouvé');
      console.log('   → Exécutez /api/seed pour initialiser les données\n');
    }

    console.log('\n✅ Tous les tests sont passés avec succès !');
    console.log('🚀 Votre base de données est prête à être utilisée.\n');
    
  } catch (error: any) {
    console.error('\n❌ Erreur lors du test de connexion:');
    console.error(`   ${error.message}\n`);
    
    if (error.message.includes('connect')) {
      console.log('💡 Solutions possibles:');
      console.log('   1. Vérifiez que les variables d\'environnement sont définies');
      console.log('   2. Vérifiez que la base de données Vercel est créée');
      console.log('   3. Vérifiez que le projet est bien connecté à la base\n');
    } else if (error.message.includes('does not exist')) {
      console.log('💡 Solution:');
      console.log('   Exécutez le script schema.sql dans la console Query de Vercel\n');
    }
    
    process.exit(1);
  }
}

// Exécuter le test
testConnection();
