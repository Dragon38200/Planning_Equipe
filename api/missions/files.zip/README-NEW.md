# 🏗️ Plani-Mounier - Application de Gestion des Chantiers

Application web complète de gestion de chantiers pour la société Mounier, avec suivi des heures des techniciens, validation par les chargés d'affaires, et formulaires personnalisables.

## ✨ Fonctionnalités principales

### 👷 Pour les Techniciens
- Saisie hebdomadaire des heures (travail, déplacement, heures supplémentaires)
- Géolocalisation automatique des chantiers
- Remplissage de formulaires personnalisés avec photos et signatures
- Suivi du statut de validation des missions

### 👔 Pour les Chargés d'Affaires
- Vue planning hebdomadaire de tous les techniciens
- Validation/Rejet des missions avec commentaires
- Gestion des interventions
- Export CSV pour comptabilité

### 🔧 Pour les Administrateurs
- Gestion complète des utilisateurs (techniciens et chargés d'affaires)
- Création et personnalisation de templates de formulaires
- Configuration de l'application (logos, paramètres)
- Historique complet des formulaires soumis
- Export ZIP des données

## 🛠️ Technologies

- **Frontend**: React 18 + TypeScript
- **Build**: Vite
- **Base de données**: Vercel Postgres
- **API**: Next.js API Routes
- **UI**: Lucide Icons, TailwindCSS
- **PDF**: jsPDF + html2canvas
- **Déploiement**: Vercel

## 📦 Installation locale

### Prérequis
- Node.js 18+
- Un compte Vercel avec une base Postgres configurée

### Étapes

1. **Cloner le projet**
```bash
git clone https://github.com/VOTRE-NOM/plani-mounier.git
cd plani-mounier
```

2. **Installer les dépendances**
```bash
npm install
```

3. **Configurer les variables d'environnement**

Créez un fichier `.env.local` à la racine du projet :

```env
# Vercel Postgres (récupérez ces valeurs depuis votre dashboard Vercel)
POSTGRES_URL="postgres://..."
POSTGRES_PRISMA_URL="postgres://..."
POSTGRES_URL_NON_POOLING="postgres://..."
POSTGRES_USER="default"
POSTGRES_HOST="..."
POSTGRES_PASSWORD="..."
POSTGRES_DATABASE="verceldb"

# Gemini API (optionnel, pour les fonctionnalités IA)
GEMINI_API_KEY="your-gemini-api-key"
```

4. **Initialiser la base de données**

Dans le dashboard Vercel, exécutez le script `schema.sql` dans la console Query.

5. **Lancer l'application en local**
```bash
npm run dev
```

L'application sera accessible sur `http://localhost:5173`

## 🚀 Déploiement sur Vercel

### Première fois

1. **Créer un compte Vercel** sur [vercel.com](https://vercel.com)

2. **Importer le projet**
   - Cliquez sur "New Project"
   - Importez votre repository GitHub
   - Vercel va détecter automatiquement la configuration

3. **Créer la base de données**
   - Allez dans **Storage** → **Create Database**
   - Choisissez **Postgres**
   - Connectez-la à votre projet

4. **Initialiser le schéma**
   - Dans Storage → votre base → **Query**
   - Exécutez le contenu de `schema.sql`

5. **Déployer**
   - Vercel déploie automatiquement à chaque push sur `main`

### Mises à jour

```bash
git add .
git commit -m "Votre message"
git push
```

Vercel redéploiera automatiquement.

## 📚 Documentation

- [Guide de migration vers Postgres](./MIGRATION_GUIDE.md)
- [Schéma de base de données](./schema.sql)
- [Structure de l'API](./api/README.md)

## 🔑 Comptes par défaut

Après l'initialisation de la base de données :

### Administrateur
- **ID**: `admin`
- **Mot de passe**: `admin123`

### Chargés d'affaires
- **ID**: `jmdupont` / Mot de passe: `jmd2024`
- **ID**: `lbernard` / Mot de passe: `lb2024`

### Techniciens
- **ID**: `jmartin` / Mot de passe: `jm2024`
- **ID**: `pdurand` / Mot de passe: `pd2024`
- **ID**: `mleroy` / Mot de passe: `ml2024`
- **ID**: `trobinson` / Mot de passe: `tr2024`

⚠️ **Important** : Changez ces mots de passe en production !

## 📊 Structure de la base de données

### Tables principales

- **users**: Utilisateurs (techniciens, chargés d'affaires, admin)
- **missions**: Missions et heures de travail
- **form_templates**: Modèles de formulaires personnalisables
- **form_responses**: Réponses aux formulaires
- **app_settings**: Paramètres de l'application

Voir [schema.sql](./schema.sql) pour le détail.

## 🧪 Tests

### Tester la connexion à la base de données

```bash
npx ts-node scripts/test-db-connection.ts
```

### Initialiser les données de test

```bash
curl -X POST https://votre-app.vercel.app/api/seed
```

## 🔧 Scripts disponibles

```bash
npm run dev        # Lance le serveur de développement
npm run build      # Build pour la production
npm run preview    # Prévisualise le build de production
npm run start      # Lance avec Vercel CLI (dev local)
```

## 📱 Fonctionnalités par rôle

### Technicien
- ✅ Saisie des heures hebdomadaires
- ✅ Géolocalisation des chantiers
- ✅ Remplissage de formulaires (photos, signatures)
- ✅ Consultation du statut de validation

### Chargé d'affaires
- ✅ Vue planning hebdomadaire
- ✅ Validation/Rejet des missions
- ✅ Ajout de commentaires
- ✅ Gestion des interventions
- ✅ Export CSV

### Administrateur
- ✅ Tout ce que font les autres rôles
- ✅ Gestion des utilisateurs
- ✅ Création de templates de formulaires
- ✅ Personnalisation de l'application
- ✅ Export complet des données

## 🎨 Personnalisation

### Logos
L'application supporte jusqu'à 10 logos personnalisables :
- Logo 1 : Logo par défaut
- Logo 2 : Logo principal (remplace le logo 1)
- Logo 3-10 : Logos additionnels pour différentes entités

### Formulaires
Créez des formulaires personnalisés avec :
- Champs texte, nombre, date
- Cases à cocher
- Listes déroulantes
- Signatures numériques
- Photos et galeries d'images

## 🔐 Sécurité

- ✅ Authentification par mot de passe
- ✅ Séparation des rôles (RBAC)
- ✅ Base de données chiffrée (Vercel Postgres)
- ✅ HTTPS obligatoire en production
- ✅ Validation des données côté serveur

⚠️ **Recommandations** :
- Changez tous les mots de passe par défaut
- Activez l'authentification à deux facteurs sur Vercel
- Configurez des sauvegardes régulières

## 📈 Limites du plan gratuit Vercel

- **Storage**: 256 MB (largement suffisant pour des milliers de missions)
- **Compute**: 60h/mois
- **Bandwidth**: 100 GB/mois

Pour un usage professionnel intensif, considérez un plan payant.

## 🐛 Résolution de problèmes

### "Failed to connect to database"
→ Vérifiez vos variables d'environnement dans Vercel

### "Table does not exist"
→ Exécutez le script `schema.sql` dans la console Query

### "500 Internal Server Error"
→ Consultez les logs dans le dashboard Vercel

## 🤝 Contribution

Les contributions sont les bienvenues ! N'hésitez pas à :
- Signaler des bugs via les Issues
- Proposer des améliorations
- Soumettre des Pull Requests

## 📄 Licence

Ce projet est la propriété de la société Mounier.

## 📞 Support

Pour toute question ou problème :
- Consultez la [documentation](./MIGRATION_GUIDE.md)
- Ouvrez une Issue sur GitHub
- Contactez l'administrateur système

---

**Développé avec ❤️ pour optimiser la gestion des chantiers Mounier**
